from django.shortcuts import render
from django.views.generic import ListView, CreateView, DeleteView
from django.urls import reverse_lazy
from .models import Membersf

class MembersListView(ListView):
    model = Membersf
    template_name = 'members/members_list.html'
    context_object_name = 'members'

class MembersCreateView(CreateView):
    model = Membersf
    fields=['name','post','image']
    success_url = reverse_lazy('members-list')

class MembersDeleteView(DeleteView):
    model = Membersf
    template_name = 'members/membersf_confirm_delete.html'
    success_url = reverse_lazy('members-list')