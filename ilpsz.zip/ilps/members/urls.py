from django.urls import path
from .views import MembersCreateView, MembersDeleteView, MembersListView

urlpatterns = [
    path('',MembersListView.as_view(),name='members-list' ),
    path('post/new/',MembersCreateView.as_view(),name="members-new"),
    path('post/<int:pk>/delete',MembersDeleteView.as_view(),name="members-delete")]