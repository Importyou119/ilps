from django.contrib import admin
from .models import Membersf
admin.site.register(Membersf)
# Register your models here.
