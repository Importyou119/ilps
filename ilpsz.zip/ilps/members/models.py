# models.py
from django.db import models
from PIL import Image

class Membersf(models.Model):  # ← This is the crucial fix
    name = models.CharField(max_length=30)
    post = models.CharField(max_length=30)
    image = models.ImageField(upload_to='memberspic/')

    def __str__(self):
        return f'{self.name}'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        img = Image.open(self.image.path)
        if img.height > 1000 or img.width > 750:
            img.thumbnail((1000, 750))
            img.save(self.image.path)
