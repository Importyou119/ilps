from django.urls import path
from . import views
from .views import createnew, PostDetailView, updatev, deletev, basic, homeaut

urlpatterns = [
    path('',basic.as_view(),name='blog-list' ),
    path('user/<str:username>/',homeaut.as_view(),name='user-name' ),
    path('post/new/',createnew.as_view(),name="blog-new"),
    path('post/<int:pk>/', PostDetailView.as_view(), name="blog-detail"),
    path('post/<int:pk>/update',updatev.as_view(),name="blog-update"),
    path('post/<int:pk>/delete',deletev.as_view(),name="blog-delete")]