from django.contrib import admin
from articles.models import comments as com
from articles.models import articles
from news.models import Newsletter
from blog.models import post, comments
admin.site.register(post)
admin.site.register(comments)
admin.site.register(Newsletter)
admin.site.register(articles)
# Register your models here.
