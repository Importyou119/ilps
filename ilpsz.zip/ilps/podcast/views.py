from django.shortcuts import render
from .models import Podcast

from django.shortcuts import render
from django.views.generic import ListView, CreateView, DeleteView
from django.urls import reverse_lazy
from .forms import podcastform

class podcastListView(ListView):
    model = Podcast
    template_name = 'podcast_list.html'
    context_object_name = 'podcasts'

class podcastCreateView(CreateView):
    model = Podcast
    form_class = podcastform
    success_url = reverse_lazy('podcast-list')

class podcastDeleteView(DeleteView):
    model = Podcast
    template_name = 'podcast/podcast_confirm_delete.html'
    success_url = reverse_lazy('podcast-list')
# Create your views here.
# Create your views here.
