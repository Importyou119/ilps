from django.contrib import admin
from .models import Podcast
admin.site.register(Podcast)
# Register your models here.
