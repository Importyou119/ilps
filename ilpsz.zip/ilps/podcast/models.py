from django.db import models


class Podcast(models.Model):
    title = models.CharField(max_length=255)
    youtube_url = models.URLField()
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def youtube_embed(self):
        return self.youtube_url.replace("watch?v=", "embed/")

    def __str__(self):
        return self.title

# Create your models here.
