from django.urls import path
from . import views

from django.urls import path
from .views import podcastCreateView, podcastDeleteView, podcastListView

urlpatterns = [
    path('',podcastListView.as_view(),name='podcast-list' ),
    path('post/new/',podcastCreateView.as_view(),name="podcast-new"),
    path('post/<int:pk>/delete',podcastDeleteView.as_view(),name="podcast-delete")]