from django.shortcuts import render, redirect
from .forms import userupdate, regist
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.utils.timezone import now, timedelta
from django.contrib import messages

def register(request):
    if request.method == 'POST':
        form = regist(request.POST)
        if form.is_valid():
            form.save()  
            messages.success(request, f'Your account has been created! Please Login.')
            print(request.POST)  
            return redirect('blog-home')
    else:
        form = regist()
    return render(request, 'users/register.html', {'form':form})

@login_required
def profile(request):

    if request.method=='POST':
        u_form=userupdate(request.POST,instance=request.user)
        if u_form.is_valid():
            u_form.save()
            return redirect('profile')
    else:
        u_form=userupdate(instance=request.user)

    context={
        'u_form':u_form,
    }
    return render(request,'users/profile.html',context)

class login_user(LoginView):
    template_name = 'users/login.html'  # Adjust this as per your template path

    def form_valid(self, form):
        response = super().form_valid(form)

        # Force the session to persist for 30 days
        self.request.session.set_expiry(30 * 24 * 60 * 60 * 12)

        return response