from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, UpdateView, DeleteView, DetailView, CreateView
from .models import articles, comments
from django.views.generic.edit import ProcessFormView, ModelFormMixin
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib.auth.models import User
from django.db.models import Q


class basic(ListView):
    model=articles
    template_name = 'articles/lis.html'
    context_object_name = 'articles'
    # This is used to order the blogs by date posted from newest to oldest. '-' means newest to oldest blog posts
    ordering = ['-date_posted']
    paginate_by = 3

    def get_queryset(self):
        query = self.request.GET.get('q')
        if query:
            return articles.objects.filter(
                Q(title__icontains=query) |
                Q(content__icontains=query) |
                Q(author__icontains=query)
            ).order_by('-date_posted')
        return super().get_queryset()

class UserPostListView(ListView):
    model = articles
    # General naming convention used for templates when using ListView is -> <app>/<model>_<viewtype>.html
    template_name = 'articles/post_aut.html'
    context_object_name = 'articles'
    # This is used to order the blogs by date posted from newest to oldest. '-' means newest to oldest blog posts
    paginate_by = 4

    def get_queryset(self):
        user = get_object_or_404(User, username=self.kwargs.get('username'))
        return articles.objects.filter(author=user).order_by('-date_posted')

'''class PostDetailView(ModelFormMixin, ProcessFormView, LoginRequiredMixin,DetailView):
    model=post
    fields=["title","content"]


    def get_context_data(self, **kwargs):
        url=self.request.path
        url1=url
        print(url1,"getua")
        url=url.replace("blog/post/","")
        url=url.replace("/","")
        url=int(url)
        self.object = self.get_object()
        b=super().get_context_data(**kwargs)
        a=post.objects.get(id=url)
        if (comments.objects.filter(post1=a)):
            context= {'post':a,'commen':comments.objects.filter(post1=a)[::-1]}
            b['extra']=context
            redirect(url1)
            return b
        else:
            context={'post':a,'commen':[]}
            b['extra']=context
            redirect(url1)
            return b

    def post(self, request, *args, **kwargs):
        self.object = self.get_object() 
        commie=request.POST.get("comment")
        url=request.path
        url1=url
        print(url1,"postua")
        url=url.replace("blog/post/","")
        url=url.replace("/","")
        url=int(url)
        a=post.objects.get(id=url)
        print(request)
        form = comments(comment_editor=request.user,post1=a,comment=commie)
        form.save()
        redirect("blog/")
        return super().post(request, *args, **kwargs)'''
from django.shortcuts import redirect
from django.urls import reverse
from django.views.generic.edit import ModelFormMixin, ProcessFormView
from django.views.generic.detail import DetailView
from django.contrib.auth.mixins import LoginRequiredMixin

class PostDetailView(ModelFormMixin, ProcessFormView, DetailView):
    model = articles
    fields = ["title", "content"]

    def get_context_data(self, **kwargs):
        self.object = self.get_object()
        context = super().get_context_data(**kwargs)

        post_instance = self.object
        all_comments = comments.objects.filter(post1=post_instance).order_by('-id')

        context['extra'] = {
            'post': post_instance,
            'commen': all_comments
        }
        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        comment_text = request.POST.get("comment")

        if comment_text:
            form = comments(
                comment_editor=request.user,
                post1=self.object,
                comment=comment_text
            )
            form.save()

        # ✅ Redirect to same detail page to prevent re-post on reload
        return redirect(self.request.path)
    
    def get_object(self):
        obj = super().get_object()
        obj.views += 1
        obj.save(update_fields=['views'])
        return obj

class createnew(LoginRequiredMixin,CreateView):
    model= articles
    fields=["author","title","content"]

    def form_valid(self, form):
        return super().form_valid(form)

class updatev(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model=articles
    fields=["title","content"]

    def form_valid(self, form):
        form.instance.author=self.request.user
        return super().form_valid(form)
    
    def test_func(self):
        pos=self.get_object()
        if self.request.user.is_superuser:
            return True
        return False

class deletev(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model=articles
    success_url='/'
    def test_func(self):
        pos=self.get_object()
        if self.request.user.username == "parikshit" :
            return True
        return False
    
class homeaut(ListView):
    model = articles
    template_name = 'articles/articles_aut.html'
    context_object_name = 'articles'
    paginate_by = 2

    def get_queryset(self):
        self.user = get_object_or_404(User, username=self.kwargs.get('username'))
        return articles.objects.filter(author=self.user).order_by('-date_posted')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['author_user'] = self.user
        return context

