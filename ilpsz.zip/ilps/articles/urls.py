from django.urls import path
from . import views
from .views import createnew, PostDetailView, updatev, deletev, basic, homeaut

urlpatterns = [
    path('',basic.as_view(),name='articles-list' ),
    path('user/<str:author>/',homeaut.as_view(),name='author-name' ),
    path('post/new/',createnew.as_view(),name="articles-new"),
    path('post/<int:pk>/',PostDetailView.as_view(),name="articles-detail"),
    path('post/<int:pk>/update',updatev.as_view(),name="articles-update"),
    path('post/<int:pk>/delete',deletev.as_view(),name="articles-delete")]