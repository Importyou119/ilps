from django.urls import path
from .views import EventsCreateView, EventsListView, EventsDeleteView, EventsDetailView

urlpatterns = [
    path('',EventsListView.as_view(),name='events-list' ),
    path('post/new/',EventsCreateView.as_view(),name="events-new"),
    path('post/<int:pk>/delete',EventsDeleteView.as_view(),name="events-delete"),
    path('post/<int:pk>/detail',EventsDetailView.as_view(),name="events-detail")]