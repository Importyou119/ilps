from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.views.generic import ListView, CreateView, DeleteView, DetailView
from django.urls import reverse_lazy
from .models import Eventsaf

class EventsListView(ListView):
    model = Eventsaf
    context_object_name = 'events'

class EventsCreateView(CreateView):
    model = Eventsaf
    fields=['title','desc','image']
    success_url = reverse_lazy('events-list')

class EventsDeleteView(DeleteView):
    model = Eventsaf
    template_name = 'events/events_confirm_delete.html'
    success_url = reverse_lazy('events-list')

class EventsDetailView(DetailView):
    model=Eventsaf