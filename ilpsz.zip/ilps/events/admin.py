from django.contrib import admin
from .models import Eventsaf
admin.site.register(Eventsaf)
# Register your models here.
