from django.db import models

# Create your models here.
# models.py
from django.db import models
from PIL import Image

class Eventsaf(models.Model):  # ← This is the crucial fix
    title = models.CharField(max_length=75)
    desc = models.TextField()
    image = models.ImageField(upload_to='eventspic/')

    def __str__(self):
        return f'{self.title}'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        img = Image.open(self.image.path)
        if img.height > 1000 or img.width > 750:
            img.thumbnail((1000, 750))
            img.save(self.image.path)
