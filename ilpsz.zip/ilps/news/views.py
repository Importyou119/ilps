from django.shortcuts import render
from django.views.generic import ListView, CreateView, DeleteView
from django.urls import reverse_lazy
from .models import Newsletter
from .forms import NewsletterForm

class NewsletterListView(ListView):
    model = Newsletter
    template_name = 'news_list.html'
    context_object_name = 'newsletters'
    ordering = ['-year', '-month']

class NewsletterCreateView(CreateView):
    model = Newsletter
    form_class = NewsletterForm
    success_url = reverse_lazy('news-list')

class NewsletterDeleteView(DeleteView):
    model = Newsletter
    template_name = 'news/news_confirm_delete.html'
    success_url = reverse_lazy('news-list')
# Create your views here.
