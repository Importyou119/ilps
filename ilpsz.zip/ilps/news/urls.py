from django.urls import path
from .views import NewsletterCreateView, NewsletterDeleteView, NewsletterListView

urlpatterns = [
    path('',NewsletterListView.as_view(),name='news-list' ),
    path('post/new/',NewsletterCreateView.as_view(),name="news-new"),
    path('post/<int:pk>/delete',NewsletterDeleteView.as_view(),name="news-delete")]