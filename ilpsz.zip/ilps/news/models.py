from django.db import models
class Newsletter(models.Model):
    month = models.CharField(max_length=20)
    year = models.CharField(max_length=4)
    file = models.FileField(upload_to='newsletters/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.month} {self.year}"
# Create your models here.
